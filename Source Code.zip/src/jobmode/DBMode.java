package jobmode;

import java.util.Objects;

import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;

import bean.InputArgs;
import constants.LNExtratterConstants;
import processor.Processor;

public class DBMode {

	private InputArgs inputArgs;
	private String inputJson;

	public DBMode(String inputJson) {
		this.inputJson = inputJson;
	}

	public void start() {
		try {
			JSONObject jsonObject = new JSONObject(inputJson);
			inputArgs = new InputArgs();
			inputArgs.setHostName(Objects.toString(jsonObject.getString(LNExtratterConstants.Hostname.getValue()), ""));
			inputArgs.setDatabaseName(
					Objects.toString(jsonObject.getString(LNExtratterConstants.Databsename.getValue()), ""));
			inputArgs.setPassword(Objects.toString(jsonObject.getString(LNExtratterConstants.Password.getValue()), ""));
			inputArgs.setCollectionList(jsonObject.getJSONArray(LNExtratterConstants.Collectionlist.getValue()));
			inputArgs.setGenMetaData(Boolean.parseBoolean(
					Objects.toString(jsonObject.getString(LNExtratterConstants.GenerateMetadata.getValue()), "")));
			inputArgs.setExtractData(Boolean.parseBoolean(
					Objects.toString(jsonObject.getString(LNExtratterConstants.ExtractData.getValue()), "")));
			inputArgs.setSipApp(Boolean.parseBoolean(
					Objects.toString(jsonObject.getString(LNExtratterConstants.SIPAPP.getValue()), "")));
			if (inputArgs.isSipApp()) {
				inputArgs.setAppName(
						Objects.toString(jsonObject.getString(LNExtratterConstants.ApplicationName.getValue()), ""));
				inputArgs.setHoldName(
						Objects.toString(jsonObject.getString(LNExtratterConstants.HoldingName.getValue()), ""));
				inputArgs.setProducerName(
						Objects.toString(jsonObject.getString(LNExtratterConstants.ProducerName.getValue()), ""));
				inputArgs.setEntityName(
						Objects.toString(jsonObject.getString(LNExtratterConstants.EntityName.getValue()), ""));
			}
			inputArgs.setOutputPath("C:\\sampleoutput");
			inputArgs.validate(inputArgs);
			Processor processor = new Processor(inputArgs);
			processor.startProcess();
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
