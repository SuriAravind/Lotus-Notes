package constants;

public enum LNExtratterConstants {

	Hostname("Hostname"),
	Databsename("Databsename"),
	Password ("Password"),
	Collectionlist("Collectionlist"),
	GenerateMetadata("GenerateMetadata"),
	ExtractData("ExtractData"),
	SIPAPP("SipApp"),
	ApplicationName("ApplicationName"),
    HoldingName("HoldingName"),
	ProducerName("ProducerName"),
	EntityName("EntityName"),
	XML("xml"),
	XLSX("xlsx"),
	ENCODING("UTF-8");
	private String value;

	private LNExtratterConstants(String value) {
		this.value = value;
	}
	public String getValue() {
		return value;
	}

	
}
