package core.xmlcore;

import enums.DataType;

public class XMLCore {

	public String datatypeXml(String code) {
		String notesDataType = DataType.getEnumByString(code);
		String xmlValidDataType = "";
		switch (DataType.valueOf(notesDataType)) {
		case DATETIMES:
			xmlValidDataType = xmlDataTypeSetter("DATETIME");
			break;
		default:
			xmlValidDataType = "VARCHAR";
			break;
		}
		return xmlValidDataType;
	}

	private String xmlDataTypeSetter(String type) {
		type = type.replace("IDENTITY", "").replace("identity", "").replace("Identity", "").trim();
		type = type.replace("UNSIGNED", "").replace("unsigned", "").replace("Unsigned", "").trim();
		type = type.replace("SIGNED", "").replace("signed", "").replace("Signed", "").trim();
		switch (type) {
		case "BOOLEAN":
		case "BIT":
			return "BOOLEAN";
		case "DATE":
			return "DATE";
		case "TIME":
			return "TIME";

		case "DATETIME":
		case "DATETIME2":
		case "TIMESTAMP":
		case "DATE TIME":
			return "DATETIME";
		case "BLOB":
		case "CLOB":
		case "TEXT":
		case "NTEXT":
		case "CHAR":
		case "NCHAR":
		case "VARCHAR":
		case "NVARCHAR":
		case "NVARBINARY":
		case "VARBINARY":
		case "PHOTO":
		case "LONGVARBINARY":
		case "LONGNVARBINARY":
		case "VARCHAR2":
		case "RAW":
		case "LONG RAW":
		case "CHARACTER":
		case "CHARACTER VARYING":
		case "BINARY VARYING":
		case "INTERVAL":
		case "TIMESTAMP WITH LOCAL TIME ZONE":
		case "TIMESTAMP WITH TIME ZONE":
		case "SMALLDATETIME":
		case "DATETIMEOFFSET":
			return "VARCHAR";
		case "INT":
		case "INTEGER":
		case "LONG":
		case "AUTONUMBER":
		case "SMALLINT":
		case "BIGINT":
		case "NUMERIC":
		case "REAL":
		case "TINYINT":
			return "INTEGER";
		case "MONEY":
		case "DEC":
		case "DECIMAL":
		case "FLOAT":
		case "DOUBLE":
		case "SMALLMONEY":
			return "DECIMAL";
		default:
			return "VARCHAR";
		}
	}

}
