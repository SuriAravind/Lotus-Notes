package core.table;

import java.io.PrintWriter;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

public class MetadataXMLFormattingHelper {


	XMLOutputFactory factory;
	XMLStreamWriter writer;

	public MetadataXMLFormattingHelper(final PrintWriter out) {
		factory = XMLOutputFactory.newInstance();
		try {
			writer = factory.createXMLStreamWriter(out);
		} catch (XMLStreamException e) {

		}
	}

	public void writeDocumentStart() {
		try {
			writer.writeStartDocument("UTF-8", "1.0");
		} catch (XMLStreamException e) {

		}
	}

	public void writeDocumentEnd() {
		try {
			writer.writeEndDocument();
		} catch (XMLStreamException e) {

		}
	}

	public void writeRootElementStart(String tablename) {
		try {
			writer.writeCharacters("\n");
			writer.writeStartElement(getTextFormatted(tablename));
		} catch (XMLStreamException e) {

		}
	}

	public void writeRootElementEnd() {
		try {
			writer.writeCharacters("\n");
			writer.writeEndElement();
		} catch (XMLStreamException e) {

		}
	}

	public void writeRecordStart(String tablename, String suffix) {
		try {
			writer.writeCharacters("\n\t");
			writer.writeStartElement(getTextFormatted(tablename + suffix));
		} catch (XMLStreamException e) {

		}
	}

	public void writeRecordEnd() {
		try {
			writer.writeCharacters("\n\t");
			writer.writeEndElement();
		} catch (XMLStreamException e) {

		}
	}

	public void writeElementStart(String columnName) {
		try {
			writer.writeCharacters("\n\t\t");
			writer.writeStartElement(columnName);
		} catch (XMLStreamException e) {

		}
	}

	public void writeElementEnd() {
		try {
			writer.writeEndElement();
		} catch (XMLStreamException e) {

		}
	}

	public void writeValue(String value) {
		try {
			writer.writeCharacters(value.trim());
		} catch (XMLStreamException e) {

		}
	}

	public void newlineWriter() {
		try {
			writer.writeCharacters("\n");
		} catch (XMLStreamException e) {

		}
	}

	public void flushOutput(PrintWriter out) {
		try {
			writer.flush();
			writer.close();
			out.flush();
			out.close();
		} catch (XMLStreamException e) {

		}
	}

	public void writeAttribute(String name, String value) {
		try {
			writer.writeAttribute(getTextFormatted(name), value);
		} catch (XMLStreamException e) {

		}
	}

	public static String getTextFormatted(String string) {
		string = string.trim().replace("$", "").replace("(", "").replace(")", "").replace("[", "").replace("]", "")
				.replace("{", "").replace("}", "").replace("/", "").replace("\\", "").replace("\"", "").replace("'", "")
				.replace("`", "").replace("&", "").replace("@", "").replace("#", "").replace("%", "").replace("!", "")
				.replace("^", "").replace("*", "").replace("|", "").replaceAll("\\s+", "_");
		return (string.charAt(0) >= '0' && string.charAt(0) <= '9') ? "_" + string : string;
	}

}
