package core.table;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeSet;

import bean.ColumnBean;
import bean.InputArgs;
import bean.TableCompleteBean;
import core.xmlcore.XMLCore;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Item;
import lotus.domino.NotesException;
import util.CommonFunction;
import util.FileUtil;

public class XMLMetadataGeneration {

	private static final String XML = ".xml";
	MetadataXMLFormattingHelper formattingHelper;
	TreeSet<String> involvedTales = new TreeSet<String>();
	private String schemaName;
	private String outputLoc;
	private InputArgs inputArgs;
	TableCompleteBean tableBean;

	public XMLMetadataGeneration(InputArgs inputArgs) {
		// this.schemaName = schemaName;
		this.outputLoc = inputArgs.getOutputPath();
	}

//TableCompleteBean tablesValues
	public synchronized String generateMetadata() throws Exception {

		FileUtil.checkCreateDirectory(outputLoc + File.separator + "METADATA");
		String file = outputLoc + File.separator + "METADATA" + File.separator + "meta_" + "schemaName" + "_"
				+ new Date().getTime() + XML;
		try {
			PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
			formattingHelper = new MetadataXMLFormattingHelper(out);
			startXML("FULL", "", tableBean.getTablesList().size());
			handleTables();
			endXML();
			formattingHelper.flushOutput(out);
			return "Metadata file generated - " + file;
		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			throw e;
		}
	}

	private void handleTables() {
		for (Entry<String, List<ColumnBean>> table : tableBean.getTablesList().entrySet()) {
			formattingHelper.writeRootElementStart("tableMetadata");
			writeElement("name", table.getKey());
			writeElement("recordCount", tableBean.getRecordData().get(table.getKey()).toString());
			formattingHelper.writeElementStart("columnList");
			final List<ColumnBean> columns = table.getValue();
			int count = 0;
			for (final ColumnBean column : columns) {
				formattingHelper.writeElementStart("column");
				handleTableColumn(column, count++);
				formattingHelper.writeElementEnd();
			}
			formattingHelper.writeElementEnd();
			formattingHelper.writeElementEnd();
		}
	}

	private void handleTableColumn(final ColumnBean column, int position) {
		writeElement("name", column.getColumnName());
//		if (columnDesc != null && !columnDesc.isEmpty())
//			writeElement("columnDesc", columnDesc);
		writeElement("ordinal", Integer.toString(position));
		writeElement("type", xmlDataTypeSetter(column.getColumnType().toUpperCase()));
		switch (column.getColumnType()) {
		case "INTEGER":
			writeElement("typeLength", "10");
			break;
		case "VARCHAR":
			writeElement("typeLength", "255");
			break;
		case "DATETIME":
		case "DATE TIME":
			writeElement("typeLength", "6");
			break;
		case "BIT":
		case "BOOLEAN":
			writeElement("typeLength", "1");
			break;
		}
		// writeElement("typeLength", (column.getTypeLength()));
		// writeElement("index", Boolean.toString(column.isIndex()));
		writeElement("index", Boolean.toString(false));
	}

	private String xmlDataTypeSetter(String type) {
		type = type.replace("IDENTITY", "").replace("identity", "").replace("Identity", "").trim();
		type = type.replace("UNSIGNED", "").replace("unsigned", "").replace("Unsigned", "").trim();
		type = type.replace("SIGNED", "").replace("signed", "").replace("Signed", "").trim();
		// return type;

		switch (type) {
		case "BOOLEAN":
		case "BIT":
			return "BOOLEAN";
		case "DATE":
			return "DATE";
		case "TIME":
			return "TIME";

		case "DATETIME":
		case "DATETIME2":
		case "TIMESTAMP":
		case "DATE TIME":
			return "DATETIME";
		case "BLOB":
		case "CLOB":
		case "TEXT":
		case "NTEXT":
		case "CHAR":
		case "NCHAR":
		case "VARCHAR":
		case "NVARCHAR":
		case "NVARBINARY":
		case "VARBINARY":
		case "PHOTO":
		case "LONGVARBINARY":
		case "LONGNVARBINARY":
		case "VARCHAR2":
		case "RAW":
		case "LONG RAW":
		case "CHARACTER":
		case "CHARACTER VARYING":
		case "BINARY VARYING":
		case "INTERVAL":
		case "TIMESTAMP WITH LOCAL TIME ZONE":
		case "TIMESTAMP WITH TIME ZONE":
		case "SMALLDATETIME":
		case "DATETIMEOFFSET":
			return "VARCHAR";
		case "INT":
		case "INTEGER":
		case "LONG":
		case "AUTONUMBER":
		case "SMALLINT":
		case "BIGINT":
		case "NUMERIC":
		case "REAL":
		case "TINYINT":
			return "INTEGER";
		case "MONEY":
		case "DEC":
		case "DECIMAL":
		case "FLOAT":
		case "DOUBLE":
		case "SMALLMONEY":
			return "DECIMAL";
		default:
			return "VARCHAR";
		}
	}

	private void writeElement(String name, String value) {
		formattingHelper.writeElementStart(name);
		formattingHelper.writeValue(value);
		formattingHelper.writeElementEnd();
	}

	private void startXML(String fullorSelected, String selectedTable, long count) {
		formattingHelper.writeDocumentStart();
		formattingHelper.writeRootElementStart("metadata");
		formattingHelper.writeAttribute("DBS", "FFG");
		formattingHelper.writeAttribute("HOST", "localhost");
		formattingHelper.writeAttribute("PORT", "00000");
		// TODO change the database from schema name to database name
		formattingHelper.writeAttribute("DATABASE", "schemaName");
		formattingHelper.writeAttribute("SCHEMA", "schemaName");
		formattingHelper.writeAttribute("FULLORSELECTED", fullorSelected);
		formattingHelper.writeAttribute("SELECTED", selectedTable);
		writeElement("caseSensitive", "false");
		writeElement("defaultSchema", "schemaName");
		writeElement("validatingOnIngest", "false");
		writeElement("locale", "en-US");
		formattingHelper.writeElementStart("schemaMetadataList");
		formattingHelper.writeElementStart("schemaMetadata");
		writeElement("name", "schemaName");
		writeElement("tableCount", Long.toString(count));
		formattingHelper.writeElementStart("tableMetadataList");
	}

	private void endXML() {
		formattingHelper.writeElementEnd();
		formattingHelper.writeRootElementEnd();
		formattingHelper.writeDocumentEnd();
	}

	public void setValuesIntoTableBean(Database db, DocumentCollection dc, List<String> formatedList)
			throws NotesException {
		Document doc = null;
		List<ColumnBean> columnList = null;
		ColumnBean columnBean = null;
		DocumentCollection coll = null;
		this.tableBean = new TableCompleteBean();
		List<String> registerTable = new ArrayList<>();
		dc = db.getAllDocuments();
		if (formatedList.isEmpty()) {
			while ((doc = dc.getNextDocument()) != null) {
				if (!registerTable.contains(doc.getItemValueString("Form"))) {
					registerTable.add(doc.getItemValueString("Form"));
					columnList = new ArrayList<ColumnBean>();
					XMLCore core = new XMLCore();
					List<Item> items = doc.getItems();
					for (Item item : items) {
						columnBean = new ColumnBean();
						columnBean.setColumnName(CommonFunction.getChangeDollerContent(item.getName()));
						columnBean.setColumnType(core.datatypeXml((String.valueOf(item.getType()))));
						columnList.add(columnBean);
					}
					coll = db.search("Form = \"" + doc.getItemValueString("Form") + "\"");
					tableBean.getRecordData().put(doc.getItemValueString("Form"), coll.getCount());
					tableBean.getTablesList().put(doc.getItemValueString("Form"), columnList);
				}
			}
		} else {
			while ((doc = dc.getNextDocument()) != null) {
				if (formatedList.contains(doc.getItemValueString("Form"))) {
					if (!registerTable.contains(doc.getItemValueString("Form"))) {
						registerTable.add(doc.getItemValueString("Form"));
						columnList = new ArrayList<ColumnBean>();
						XMLCore core = new XMLCore();
						List<Item> items = doc.getItems();
						for (Item item : items) {
							columnBean = new ColumnBean();
							columnBean.setColumnName(CommonFunction.getChangeDollerContent(item.getName()));
							columnBean.setColumnType(core.datatypeXml((String.valueOf(item.getType()))));
							columnList.add(columnBean);
						}
						coll = db.search("Form = \"" + doc.getItemValueString("Form") + "\"");
						tableBean.getRecordData().put(doc.getItemValueString("Form"), coll.getCount());
						tableBean.getTablesList().put(doc.getItemValueString("Form"), columnList);
					}
				}
			}
		}

	}

}
