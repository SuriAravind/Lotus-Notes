package core.table;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.util.Date;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import bean.InputArgs;
import constants.LNExtratterConstants;
import core.report.ReportGenerator;
import util.FileUtil;

public class ConvertXml {
	InputArgs inputArgs;
	String outputDirPath;
	protected String outputFilePath;
	protected Writer out;
	private XMLOutputFactory factory;
	protected XMLStreamWriter writer;
	protected FileChannel outputFile;
	protected String schemaName;
	protected String tableName;
	protected int rollingNumber;
	protected long startTime;
	protected long endTime;
	protected int sourceCount = 0;
	protected int destinationCount = 0;
	XMLMetadataGeneration metadataGeneration;
	private String rowCountFile;
	private int csvFileCountDE = 0;
	private int csvFileCountME = 0;
	protected boolean isFileProcessed = true;
	private String status;
	private String errorMsg;

	public ConvertXml(InputArgs inputArgs) throws IOException {
		this.inputArgs = inputArgs;
		this.schemaName = inputArgs.getDatabaseName();
		this.outputDirPath = inputArgs.getOutputPath() + File.separator + "schemaName";

		rowCountFile = inputArgs.getOutputPath() + File.separator + "row_count_" + new Date().getTime() + ".csv";
		try {
			FileUtil.checkCreateDirectory(inputArgs.getOutputPath());
			new File(rowCountFile).createNewFile();
			inputArgs.setRowCountFileLoc(rowCountFile);
			writeRowCount(
					"FILE_COUNT,OUTPUT_FILE,SOURCE_RECORD_COUNT,DESTINATION_RECORD_COUNT,START_TIME,END_TIME,PROCESSING_TIME,STATUS,REASON\n",
					rowCountFile);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Unable to create row count info file " + e.getMessage() + "\nTerminating...");
			System.exit(4);
		}

		FileUtil.createDir(outputDirPath);
	}

	protected synchronized void writeRowCount(String text, String fileName) {
		try {
			if (fileName.equals(rowCountFile)) {
				if (csvFileCountDE != 0)
					text = csvFileCountDE++ + "," + text;
				else
					csvFileCountDE++;
				FileUtil.writeFile(fileName, text);
			} else {
				if (csvFileCountME != 0)
					text = csvFileCountME++ + "," + text;
				else
					csvFileCountME++;
				FileUtil.writeFile(fileName, text);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String getXmlFileName() {
		return "schemaName" + "-" + tableName + "-" + "." + LNExtratterConstants.XML.getValue();
	}

	protected void createOuputFile(String tablename) throws Exception {
		this.tableName = tablename;
		if (inputArgs.isSipApp()) {
		} else {
			outputFilePath = outputDirPath + File.separator + getXmlFileName();
			out = new OutputStreamWriter(new FileOutputStream(outputFilePath),
					LNExtratterConstants.ENCODING.getValue());
			out.write("");
			out.flush();
			outputFile = FileChannel.open(Paths.get(outputFilePath), StandardOpenOption.READ);
		}
		if (inputArgs.isSipApp()) {
		} else {
			factory = XMLOutputFactory.newInstance();
			writer = factory.createXMLStreamWriter(out);
			header();
		}
	}

	private void header() throws XMLStreamException {
		writer.writeStartDocument(LNExtratterConstants.ENCODING.getValue(), "1.0");
		writer.writeCharacters("\n");
		writer.writeStartElement("schemaName");
		writer.writeCharacters("\n");
		writer.writeStartElement(tableName);
		// writer.writeAttribute("ROLL_ID", Integer.toString(rollingNumber));
	}

	protected void getRowElement(long id) throws XMLStreamException {
		writer.writeCharacters("\n\t");
		writer.writeStartElement("ROW");
		writer.writeAttribute("REC_ID", Long.toString(id));
	}

	protected void createElemenet(String ele, String value) throws XMLStreamException {
		writer.writeCharacters("\n\t\t");
		writer.writeStartElement(ele);

		if (value == "NA!!!==@@" || value == null) {
			writer.writeAttribute("NULL", "true");
			writer.writeCharacters(" ");
		} else {
			writer.writeCharacters(value.trim());
		}
		writer.writeEndElement();
		writer.flush();
	}

	protected void footer() throws XMLStreamException, IOException {
		writer.writeCharacters("\n");
		writer.writeEndElement();
		writer.writeEndDocument();
		writer.flush();
		writer.close();
		if (out != null) {
			out.flush();
			out.close();
		}
		try {
			if (outputFile != null && outputFile.isOpen()) {
				outputFile.close();
			}
		} catch (Exception e) {

		}
	}

	protected void updateRowCountFile() {
		if (isFileProcessed) {
			status = "SUCCESS";
			errorMsg = "";
		} else {
			sourceCount = 0;
			destinationCount = 0;
			if (inputArgs.isExtractData()) {
				status = "FAILED";
				errorMsg = "WE CAN'T EXTRACTION : ";
				deleteXMLFile(outputFilePath);
			}
		}

		writeRowCount(outputFilePath + "," + sourceCount + "," + destinationCount + ","
				+ new Timestamp(startTime).toString() + "," + new Timestamp(endTime).toString() + ","
				+ ReportGenerator.timeDiff(endTime - startTime) + "," + status + "," + errorMsg + "\n", rowCountFile);

	}

	private void deleteXMLFile(String outputFile) {
		try {
			if (outputFile != null && FileUtil.checkForFile(outputFile))
				FileUtil.deleteFile(outputFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getOutputFilePath() {
		return outputFilePath;
	}

	public void setOutputFilePath(String outputFilePath) {
		this.outputFilePath = outputFilePath;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public long getStartTime() {
		return startTime;
	}

	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	public FileChannel getOutputFile() {
		return outputFile;
	}

	public void setOutputFile(FileChannel outputFile) {
		this.outputFile = outputFile;
	}

	public boolean isFileProcessed() {
		return isFileProcessed;
	}

	public void setFileProcessed(boolean isFileProcessed) {
		this.isFileProcessed = isFileProcessed;
	}

}
