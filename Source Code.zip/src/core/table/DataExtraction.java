package core.table;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bean.InputArgs;
import bean.TableCompleteBean;
import core.xmlcore.XMLCore;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Item;
import lotus.domino.NotesException;
import util.CommonFunction;

public class DataExtraction extends ConvertXml {
	InputArgs inputArgs;
	TableCompleteBean tableBean;

	public DataExtraction(InputArgs inputArgs) throws IOException {
		super(inputArgs);
	}

	public void setExtractionValuesIntoBean(Database db, DocumentCollection dc, List<String> formatedList)
			throws Exception {
		Document doc = null;
		DocumentCollection dcColl = db.getAllDocuments();
		DocumentCollection coll = null;
		DocumentCollection forextraction = dc;
		try {
			for (String tableName : formatedList) {
				startTime=new Date().getTime();
				int count = 0;
				sourceCount=0;
				destinationCount=0;
				createOuputFile(tableName);
				dcColl = db.getAllDocuments();
				while ((doc = dcColl.getNextDocument()) != null) {

					if (tableName.equalsIgnoreCase(doc.getItemValueString("Form"))) {
						count++;
						sourceCount++;
						getRowElement(count);
						XMLCore core = new XMLCore();
						List<Item> items = doc.getItems();
						for (Item item : items) {
							createElemenet(CommonFunction.getChangeDollerContent(item.getName()), item.getValueString());
						}
						writer.writeCharacters("\n\t");
						writer.writeEndElement();
						writer.flush();
						destinationCount++;
					}
				}

				System.out.println(
						"Processed records (" + tableName + ") for file = " + outputFilePath + " " + sourceCount);
				System.out.println(
						"Converted records for (" + tableName + ") file = " + outputFilePath + " " + destinationCount);
				footer();
				endTime = new Date().getTime();
				updateRowCountFile();
			}
		} catch (NotesException e) {
			e.printStackTrace();
		}
	}

	public List<String> getFormList(Database db, DocumentCollection dc, List<String> formatedList)
			throws NotesException {
		Document doc = null;
		DocumentCollection coll = null;
		DocumentCollection forextraction = dc;
		List<String> registerTable = new ArrayList<>();
		if (formatedList.isEmpty()) {

			while ((doc = dc.getNextDocument()) != null) {
				if (!registerTable.contains(doc.getItemValueString("Form"))) {
					registerTable.add(doc.getItemValueString("Form"));
				}
			}
		} else {
			registerTable = formatedList;
		}
		return registerTable;
	}

}
