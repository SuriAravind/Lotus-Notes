package core.sip;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bean.InputArgs;
import core.report.ReportGenerator;
import core.xmlcore.XMLCore;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Item;
import lotus.domino.NotesException;
import util.CommonFunction;
import util.FileUtil;

public class SipExtraction {
	private InputArgs inputArgs;
	private SipCreator sipCreator;
	private String rowCountFile;
	private int csvFileCountDE = 0;
	private int csvFileCountME = 0;
	private boolean isFileProcessed = true;
	private String status;
	private String errorMsg;
	private long startTime;
	private long endTime;
	private int sourceCount = 0;
	private int destinationCount = 0;
	private String tableName;
	private StringBuffer stringBuffer = new StringBuffer("");
	private RecordData recordData;

	public SipExtraction(InputArgs inputArgs) {
		this.inputArgs = inputArgs;
		rowCountFile = inputArgs.getOutputPath() + File.separator + "row_count_" + new Date().getTime() + ".csv";
		try {
			FileUtil.checkCreateDirectory(inputArgs.getOutputPath());
			new File(rowCountFile).createNewFile();
			inputArgs.setRowCountFileLoc(rowCountFile);
			writeRowCount(
					"FILE_COUNT,OUTPUT_FILE,SOURCE_RECORD_COUNT,DESTINATION_RECORD_COUNT,START_TIME,END_TIME,PROCESSING_TIME,STATUS,REASON\n",
					rowCountFile);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Unable to create row count info file " + e.getMessage() + "\nTerminating...");
			System.exit(4);
		}
	}

	protected synchronized void writeRowCount(String text, String fileName) {
		try {
			if (fileName.equals(rowCountFile)) {
				if (csvFileCountDE != 0)
					text = csvFileCountDE++ + "," + text;
				else
					csvFileCountDE++;
				FileUtil.writeFile(fileName, text);
			} else {
				if (csvFileCountME != 0)
					text = csvFileCountME++ + "," + text;
				else
					csvFileCountME++;
				FileUtil.writeFile(fileName, text);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void extractDataExtraction(Database db, DocumentCollection dc, List<String> formatedList) throws Exception {

		Document doc = null;
		DocumentCollection dcColl = db.getAllDocuments();
		DocumentCollection coll = null;
		DocumentCollection forextraction = dc;
		try {
			for (String tableName : formatedList) {
				startTime = new Date().getTime();
				int count = 0;
				sourceCount = 0;
				destinationCount = 0;
				sipCreator = new SipCreator(inputArgs, "schemaName", tableName, 1);
				dcColl = db.getAllDocuments();
				while ((doc = dcColl.getNextDocument()) != null) {
					if (tableName.equalsIgnoreCase(doc.getItemValueString("Form"))) {
						count++;
						sourceCount++;
						// getRowElement(count);
						stringBuffer.append("\n\t");
						stringBuffer.append("\n\t");
						stringBuffer.append("<" + tableName.toUpperCase() + "_ROW REC_ID=\"" + count + "\">");
						XMLCore core = new XMLCore();
						List<Item> items = doc.getItems();
						for (Item item : items) {
//							createElemenet(CommonFunction.getChangeDollerContent(item.getName()),
//									item.getValueString());
							stringBuffer.append("<"
									+ CommonFunction.getChangeDollerContent(item.getName() + ">" + item.getValueString()
											+ "</" + CommonFunction.getChangeDollerContent(item.getName()) + ">"));
						}
						stringBuffer.append("\n\t");
						stringBuffer.append("</" + tableName.toUpperCase() + "_ROW>");
						destinationCount++;
						recordData = new RecordData(stringBuffer.toString());
						sipCreator.getBatchAssembler().add(recordData);
						stringBuffer.delete(0, stringBuffer.length());
					}
				}
				sipCreator.getBatchAssembler().end();
				System.out.println("Processed records (" + tableName + ") for file = " + inputArgs.getOutputPath()
						+ File.separator + "schemaName" + File.separator + "sip-" + tableName + "0" + ".zip" + " "
						+ sourceCount);
				System.out.println("Converted records for (" + tableName + ") file = " + inputArgs.getOutputPath()
						+ File.separator + "schemaName" + File.separator + "sip-" + tableName + "0" + ".zip" + " "
						+ destinationCount);
				endTime = new Date().getTime();
				updateRowCountFile();
			}

		} catch (NotesException e) {
			e.printStackTrace();
		}

	}

	private void updateRowCountFile() {
		if (isFileProcessed) {
			status = "SUCCESS";
			errorMsg = "";
		} else {
			sourceCount = 0;
			destinationCount = 0;
			if (inputArgs.isExtractData()) {
				status = "FAILED";
				errorMsg = "WE CAN'T EXTRACTION : ";
				// deleteXMLFile(outputFilePath);
			}
		}

		writeRowCount(
				inputArgs.getOutputPath() + File.separator + "schemaName" + File.separator + "sip-" + tableName + "0"
						+ ".zip" + "," + sourceCount + "," + destinationCount + ","
						+ new Timestamp(startTime).toString() + "," + new Timestamp(endTime).toString() + ","
						+ ReportGenerator.timeDiff(endTime - startTime) + "," + status + "," + errorMsg + "\n",
				rowCountFile);

	}

	public List<String> getFormList(Database db, DocumentCollection dc, List<String> formatedList)
			throws NotesException {
		Document doc = null;
		DocumentCollection coll = null;
		DocumentCollection forextraction = dc;
		List<String> registerTable = new ArrayList<>();
		if (formatedList.isEmpty()) {

			while ((doc = dc.getNextDocument()) != null) {
				if (!registerTable.contains(doc.getItemValueString("Form"))) {
					registerTable.add(doc.getItemValueString("Form"));
				}
			}
		} else {
			registerTable = formatedList;
		}
		return registerTable;
	}
}
