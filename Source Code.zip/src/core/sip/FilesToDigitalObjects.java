package core.sip;

import java.util.Arrays;
import java.util.Iterator;

import com.emc.ia.sdk.sip.assembly.DigitalObject;
import com.emc.ia.sdk.sip.assembly.DigitalObjectsExtraction;

public class FilesToDigitalObjects implements DigitalObjectsExtraction<RecordData> {
	String attachmentLoc;

	@Override
	public Iterator<? extends DigitalObject> apply(RecordData recordData) {
		return Arrays.stream(getData(recordData)).iterator();
	}

	private DigitalObject[] getData(RecordData recordData) {
		DigitalObject[] digObj = new DigitalObject[0];
		return digObj;
	}
}