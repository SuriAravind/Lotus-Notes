package core.sip;

import java.io.File;

import com.emc.ia.sdk.sip.assembly.BatchSipAssembler;
import com.emc.ia.sdk.sip.assembly.DefaultPackagingInformationFactory;
import com.emc.ia.sdk.sip.assembly.OneSipPerDssPackagingInformationFactory;
import com.emc.ia.sdk.sip.assembly.PackagingInformation;
import com.emc.ia.sdk.sip.assembly.PackagingInformationFactory;
import com.emc.ia.sdk.sip.assembly.PdiAssembler;
import com.emc.ia.sdk.sip.assembly.SequentialDssIdSupplier;
import com.emc.ia.sdk.sip.assembly.SipAssembler;
import com.emc.ia.sdk.sip.assembly.SipSegmentationStrategy;
import com.emc.ia.sdk.sip.assembly.TemplatePdiAssembler;
import com.emc.ia.sdk.support.io.FileSupplier;
import com.emc.ia.sip.assembly.stringtemplate.StringTemplate;

import bean.InputArgs;

public class SipCreator {

	private String appName;
	private String holding;
	private String producer;
	private String namespace;
	private String entity;
	private long rpx;
	protected String outputPath;
	protected BatchSipAssembler<RecordData> batchAssembler;
	private String sipFileName;
	private int tableFileCount;

	public SipCreator(InputArgs argsBean, String schemaName, String tableName, int tableFileCount) throws Exception {
		this.outputPath = argsBean.getOutputPath() + File.separator + schemaName;
		this.rpx = 100*1024*1024;
		this.appName = argsBean.getAppName();
		this.holding = argsBean.getHoldName() + "_" + tableName;
		this.producer = argsBean.getProducerName();
		this.entity = argsBean.getEntityName();
		this.namespace = "urn:x-emc:eas:schema:" + holding + ":1.0";
		this.sipFileName = tableName;
		this.tableFileCount = tableFileCount;
		create();
	}

	private void create() {

		PackagingInformation prototype = PackagingInformation.builder().dss().application(appName).holding(holding)
				.producer(producer).entity(entity).schema(namespace).end().build();

		PackagingInformationFactory factory = new OneSipPerDssPackagingInformationFactory(
				new DefaultPackagingInformationFactory(prototype), new SequentialDssIdSupplier("ex6dss", 1));

		String sipHeader = "<TABLE_" + sipFileName.toUpperCase() + " xmlns=\"" + namespace + "\">\n";
		String sipFooter = "</TABLE_" + sipFileName.toUpperCase() + ">\n";

		PdiAssembler<RecordData> pdiAssembler = new TemplatePdiAssembler<>(
				new StringTemplate<>(sipHeader, sipFooter, "$model.data$\n"));

		SipAssembler<RecordData> sipAssembler = SipAssembler.forPdiAndContent(factory, pdiAssembler,
				new FilesToDigitalObjects());

		batchAssembler = new BatchSipAssembler<>(sipAssembler, SipSegmentationStrategy.byMaxSipSize(rpx), FileSupplier
				.fromDirectory(new File(outputPath), "sip-" + sipFileName + "-" + tableFileCount + "-", ".zip"));
	}

	public BatchSipAssembler<RecordData> getBatchAssembler() {
		return batchAssembler;
	}

}
