package core.sip;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bean.ColumnBean;
import bean.InputArgs;
import bean.TableCompleteBean;
import core.xmlcore.XMLCore;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Item;
import lotus.domino.NotesException;
import util.CommonFunction;
import util.FileUtil;
import java.io.OutputStreamWriter;

public class PdiSchemaGeneration {

	private InputArgs inputArgs;
	private String schemaName;
	private String tableName;
	private String holdingName;
	private String outputPath;
	private Writer out;
	private static final String ENCODING = "UTF-8";
	private int level = 0;
	private String filePath;

	public PdiSchemaGeneration(InputArgs inputArgs) {
		this.inputArgs = inputArgs;
		this.schemaName = "schemaName";
		this.outputPath = inputArgs.getOutputPath();
		
	}
	public void startPdiSchema(String tablename, List<ColumnBean> columns) throws Exception {
		this.tableName=tablename;
		this.holdingName = inputArgs.getHoldName() + "_" + tableName;
		String MetaDataFolderPath = outputPath + File.separator + "PDI_SCHEMA";
		if (!FileUtil.checkForDirectory(MetaDataFolderPath))
			FileUtil.createDir(MetaDataFolderPath);
		 filePath = MetaDataFolderPath + File.separator + "pdi-" + schemaName.toUpperCase() + "_"
				+ tableName.toUpperCase() + ".xsd";
		String nameSpace = "urn:x-emc:eas:schema:" + holdingName + ":1.0";
		out = new OutputStreamWriter(new FileOutputStream(new File(filePath)), ENCODING);
		out.write("<?xml version=\"1.0\" encoding=\"");
		out.write(ENCODING);
		out.write("\"?>");
		out.write(getTabSpace(level++)
				+ "<xs:schema attributeFormDefault=\"unqualified\" elementFormDefault=\"qualified\" ");
		out.write("targetNamespace=\"");
		out.write(nameSpace + "\" ");
		out.write("xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"");
		out.write(">");
		out.write(getTabSpace(level++) + "<xs:element name=\"TABLE_" + tableName + "\">");
		out.write(getTabSpace(level++) + "<xs:complexType>");
		out.write(getTabSpace(level++) + "<xs:sequence>");
		out.write(getTabSpace(level++) + "<xs:element maxOccurs=\"unbounded\" minOccurs=\"0\" name=\"" + tableName
				+ "_ROW\">");
		out.write(getTabSpace(level++) + "<xs:complexType>");
		out.write(getTabSpace(level++) + "<xs:sequence>");
		for (ColumnBean column : columns) {
			if (column.getColumnType().equals("DATE") || column.getColumnType().equals("DATE TIME")) {
				out.write(getTabSpace(level) + "<xs:element name=\"" + column.getColumnName() + "\" type=\""
						+ "xs:string" + "\"/>");
				out.write(getTabSpace(level) + "<xs:element name=\"" + column.getColumnName() + "_DT_COMPATIBLE\">");
				level++;
				out.write(getTabSpace(level++) + "<xs:complexType>");
				out.write(getTabSpace(level++) + "<xs:simpleContent>");
				out.write(getTabSpace(level++) + "<xs:extension base=\"xs:dateTime\">");
				out.write(getTabSpace(level++)
						+ "<xs:attribute name=\"createdBy\" type=\"xs:string\" use=\"optional\"/>");
				level -= 2;
				out.write(getTabSpace(level--) + "</xs:extension>");
				out.write(getTabSpace(level--) + "</xs:simpleContent>");
				out.write(getTabSpace(level--) + "</xs:complexType>");
				out.write(getTabSpace(level) + "</xs:element>");
			} else {
				out.write(getTabSpace(level) + "<xs:element name=\"" + column.getColumnName() + "\" type=\""
						+ getColumnType(column.getColumnType()) + "\"/>");
			}
		}
		out.write(getTabSpace(level--) + "</xs:sequence>");
		out.write(getTabSpace(level) + "<xs:attribute name=\"REC_ID\" type=\"xs:long\" use=\"required\" />");
		out.write(getTabSpace(level--) + "</xs:complexType>");
		out.write(getTabSpace(level--) + "</xs:element>");
		out.write(getTabSpace(level--) + "</xs:sequence>");
		out.write(getTabSpace(level--) + "</xs:complexType>");
		out.write(getTabSpace(level--) + "</xs:element>");
		out.write("\n</xs:schema>");
		out.flush();
		out.close();
		System.out.println("pdi schema file created\n");
	}

	private int i = 0;
	private String tabSpace = "\n";

	private String getTabSpace(int tabSize) {
		if (tabSize < 0)
			return "";
		i = 0;
		tabSpace = "\n";
		while (i++ != tabSize) {
			tabSpace += "\t";
		}
		return tabSpace;
	}

	private String getColumnType(String colType) {
		switch (colType.toUpperCase()) {
		case "CHAR":
		case "VARCHAR":
		case "TEXT":
		case "TINYTEXT":
		case "MEDIUMTEXT":
		case "LONGTEXT":
		case "USERDEFINED":
			return "xs:string";
		case "INTEGER":
		case "INT":
			return "xs:int";
		case "LONG":
			return "xs:long";
		case "DOUBLE":
		case "DECIMAL":
			return "xs:double";
		case "DATE":
			return "xs:date";
		case "DATE TIME":
		case "TIMESTAMP":
		case "TIMESTAMP_WITH_TIMEZONE":
			return "xs:dateTime";
		default:
			return "xs:string";
		}
	}

	public void setValuesIntoTableBean(Database db, DocumentCollection dc, List<String> formatedList)
			throws NotesException, Exception {

		Document doc = null;
		List<ColumnBean> columnList = null;
		ColumnBean columnBean = null;
		DocumentCollection coll = null;
		List<String> registerTable = new ArrayList<>();
		dc = db.getAllDocuments();
		if (formatedList.isEmpty()) {
			while ((doc = dc.getNextDocument()) != null) {
				if (!registerTable.contains(doc.getItemValueString("Form"))) {
					registerTable.add(doc.getItemValueString("Form"));
					columnList = new ArrayList<ColumnBean>();
					XMLCore core = new XMLCore();
					List<Item> items = doc.getItems();
					for (Item item : items) {
						columnBean = new ColumnBean();
						columnBean.setColumnName(CommonFunction.getChangeDollerContent(item.getName()));
						columnBean.setColumnType(core.datatypeXml((String.valueOf(item.getType()))));
						columnList.add(columnBean);
					}
					startPdiSchema(doc.getItemValueString("Form"), columnList);
				}
			}
		} else {
			while ((doc = dc.getNextDocument()) != null) {
				if (formatedList.contains(doc.getItemValueString("Form"))) {
					if (!registerTable.contains(doc.getItemValueString("Form"))) {
						registerTable.add(doc.getItemValueString("Form"));
						columnList = new ArrayList<ColumnBean>();
						XMLCore core = new XMLCore();
						List<Item> items = doc.getItems();
						for (Item item : items) {
							columnBean = new ColumnBean();
							columnBean.setColumnName(CommonFunction.getChangeDollerContent(item.getName()));
							columnBean.setColumnType(core.datatypeXml((String.valueOf(item.getType()))));
							columnList.add(columnBean);
						}
						startPdiSchema(doc.getItemValueString("Form"), columnList);
					}
				}
			}
		}

		
		
	}
}
