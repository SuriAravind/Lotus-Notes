package util;

public class CommonFunction {
	public  static String getChangeDollerContent(String columnElementValue) {
		String changedValue = "";
		if (columnElementValue.contains("$")) {
			columnElementValue = columnElementValue.replace('$', '_');
			changedValue = "DOLLAR" + columnElementValue;
		} else {
			changedValue = columnElementValue;
		}
		return changedValue;
	}
}
