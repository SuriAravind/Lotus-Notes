package bean;

import java.util.List;

public class InputArgs {
	private String hostName;
	private String databaseName;
	private String password;
	private List<String> collectionList;
	private boolean genMetaData;
	private boolean extractData;
	private boolean isSipApp;
	private String appName;
	private String holdName;
	private String producerName;
	private String entityName;
	private String outputPath;
	private String rowCountFileLoc;

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<String> getCollectionList() {
		return collectionList;
	}

	public void setCollectionList(List<String> collectionList) {
		this.collectionList = collectionList;
	}

	public boolean isGenMetaData() {
		return genMetaData;
	}

	public void setGenMetaData(boolean genMetaData) {
		this.genMetaData = genMetaData;
	}

	public boolean isExtractData() {
		return extractData;
	}

	public void setExtractData(boolean extractData) {
		this.extractData = extractData;
	}

	public boolean isSipApp() {
		return isSipApp;
	}

	public void setSipApp(boolean isSipApp) {
		this.isSipApp = isSipApp;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getHoldName() {
		return holdName;
	}

	public void setHoldName(String holdName) {
		this.holdName = holdName;
	}

	public String getProducerName() {
		return producerName;
	}

	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public void validate(InputArgs inputArgs) {
		if (inputArgs.getHostName().isEmpty() || inputArgs.getHostName() == null) {
			System.out.println("Host Name Required");
			System.exit(0);
		}
		if (inputArgs.getDatabaseName().isEmpty() || inputArgs.getDatabaseName() == null) {
			System.out.println("Database Name Required");
			System.exit(0);
		}
		if (inputArgs.getPassword().isEmpty() || inputArgs.getPassword() == null) {
			System.out.println("Password Required");
			System.exit(0);
		}

	}
	public String getOutputPath() {
		return outputPath;
	}

	public void setOutputPath(String outputPath) {
		this.outputPath = outputPath;
	}

	public String getRowCountFileLoc() {
		return rowCountFileLoc;
	}

	public void setRowCountFileLoc(String rowCountFileLoc) {
		this.rowCountFileLoc = rowCountFileLoc;
	}

}
