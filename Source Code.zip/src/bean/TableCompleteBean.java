package bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TableCompleteBean  implements Serializable {
	private static final long serialVersionUID = 1L;
	private static Map<String, List<ColumnBean>> tablesList = new HashMap<>();
	private static Map<String,Integer> recordData=new HashMap<>();
	public static Map<String, List<ColumnBean>> getTablesList() {
		return tablesList;
	}
	public static void setTablesList(Map<String, List<ColumnBean>> tablesList) {
		TableCompleteBean.tablesList = tablesList;
	}
	public static Map<String, Integer> getRecordData() {
		return recordData;
	}
	public static void setRecordData(Map<String, Integer> recordData) {
		TableCompleteBean.recordData = recordData;
	}

	

}
