package test;
import lotus.domino.*;
 
public class Test extends NotesThread
{
    public static void main(String argv[])    
    {    
    	try {
			String ip = "EC2AMAZ-MUO7U47";//EC2AMAZ-MUO7U47/Platform";
    		// Connect to server
			String host = ip + ":63148";            
            Session s = NotesFactory.createSession(host,"Administrator/Platform","Platform@2019");
            Database db = s.getDatabase(ip + "/Platform", "names.nsf");
            System.out.print(db.getTitle());
            loopalldocuments(db);
            s.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public static void loopalldocuments(Database db) {
    	
//    	DocumentCollection coll;
		try {
//			coll = db.getAllDocuments();
////			DocumentCollection col1 = db.search("Form='Person'");
//			Document doc = coll.getFirstDocument();
//	    	while (doc!=null) {
//	    		
//	    		doc= coll.getNextDocument(doc);
//	    		System.out.println(doc.getItems());
//	    			
//	    	}
	    	
	    	DocumentCollection dc = db.search
	    		      ("Form = \"Person\"");
	    		      int matches = dc.getCount();
	    		      System.out.println("Matches " + matches);
	    		      
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
    
    public static void getDocumentByForm() {
    	
    	
    }
}


