package processor;

import java.util.ArrayList;
import java.util.List;

import bean.ColumnBean;
import bean.InputArgs;
import bean.TableCompleteBean;
import core.report.ReportGenerator;
import core.sip.PdiSchemaGeneration;
import core.sip.SipExtraction;
import core.table.DataExtraction;
import core.table.XMLMetadataGeneration;
import core.xmlcore.XMLCore;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Item;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class Processor extends NotesThread {
	private InputArgs inputArgs;
	XMLMetadataGeneration metadataGeneration;
	PdiSchemaGeneration pdiSchemaGeneration;
	DocumentCollection dc;
	List<String> lists = null;
	List<String> formatedList = new ArrayList<String>();
	SipExtraction sipExtraction;

	public Processor(InputArgs inputArgs) {
		this.inputArgs = inputArgs;
	}

	public void startProcess() throws Exception {
		try {
			String ip = inputArgs.getHostName().split("\\/")[0];// EC2AMAZ-MUO7U47/Platform";
			String host = ip + ":63148";
			Session s = NotesFactory.createSession(host, "Administrator/Platform", "Platform@2019");
			Database db = s.getDatabase(ip + "/Platform", "names.nsf");
			System.out.println(db.getFilePath().toUpperCase());
			lists = inputArgs.getCollectionList();
			dc = db.getAllDocuments();
			if (lists.isEmpty()) {
				for (String list : lists) {
					formatedList.add(getTextFormatted(list));
				}
			}

			if (inputArgs.isSipApp()) {
				if (inputArgs.isGenMetaData()) {
					pdiSchemaGeneration=new PdiSchemaGeneration(inputArgs);
					pdiSchemaGeneration.setValuesIntoTableBean(db, dc, formatedList);
				}
				if (inputArgs.isExtractData()) {
				   sipExtraction=new SipExtraction(inputArgs);
				   List<String> formList = sipExtraction.getFormList(db, dc, formatedList);
				   sipExtraction.extractDataExtraction(db, dc, formList);
				}
			} else {
				if (inputArgs.isGenMetaData()) {
					metadataGeneration = new XMLMetadataGeneration(inputArgs);
					metadataGeneration.setValuesIntoTableBean(db, dc, formatedList);
					metadataGeneration.generateMetadata();
				}
				if (inputArgs.isExtractData()) {
					DataExtraction dataExtraction = new DataExtraction(inputArgs);
					List<String> formList = dataExtraction.getFormList(db, dc, formatedList);
					dataExtraction.setExtractionValuesIntoBean(db, dc, formList);
				}
			}
			if (inputArgs.isGenMetaData() || inputArgs.isExtractData()) {
				ReportGenerator reportGenerator = new ReportGenerator(inputArgs);
				reportGenerator.setValuesIntoBean(db, dc, formatedList);
				if (inputArgs.isGenMetaData()) {
					reportGenerator.generateMetadataExtractionReport("");
				}
				if (inputArgs.isExtractData()) {
					reportGenerator.generateDataExtractionReport(inputArgs.getRowCountFileLoc());
				}
			}
			s.recycle();
		} catch (NotesException e) {
			e.printStackTrace();
		}
	}

	public static String getTextFormatted(String string) {
		string = string.trim().replaceAll("[^_^\\p{Alnum}.]", "_").replace("^", "_").replaceAll("\\s+", "_");
		string = ((string.startsWith("_") && string.endsWith("_") && string.length() > 2)
				? string.substring(1).substring(0, string.length() - 2)
				: string);
		return string.length() > 0 ? ((string.charAt(0) >= '0' && string.charAt(0) <= '9') ? "_" : "") + string
				: string;
	}

}
