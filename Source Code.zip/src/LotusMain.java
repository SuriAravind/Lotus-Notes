import jobmode.DBMode;

public class LotusMain 
{
    public static void main(String args[])    
    {    
		String arg="{\r\n" + 
				"\"Hostname\":\"EC2AMAZ-MUO7U47/Platform\",\r\n" + 
				"\"Databsename\":\"mail/administ.nsf\",\r\n" + 
				"\"Password\":\"Platform@2019\",\r\n" + 
				"\"Collectionlist\":[\"Person\",\"country\"],\r\n" + 
				"\"GenerateMetadata\":true,\r\n" + 
				"\"ExtractData\":true,\r\n" + 
				"\"SipApp\":false,\r\n" + 
				"\"ApplicationName\":\"app\",\r\n" + 
				"\"HoldingName\":\"hold\",\r\n" + 
				"\"ProducerName\":\"prod\",\r\n" + 
				"\"EntityName\":\"entity\"\r\n" + 
				"}";
//		if (args.length == 0) {
//			System.err.println("No arguments specified.\nTerminating ... ");
//			System.out.println("Job Terminated = " + new Date());
//			System.exit(1);
//		}
		//else {
		 DBMode dbmode=new DBMode(arg);	
		 dbmode.start();
		//}
    }
}
